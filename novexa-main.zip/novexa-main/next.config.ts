import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  // three is shipped as ESM; transpile for older bundling targets
  transpilePackages: ["three"],
  images: { formats: ["image/avif", "image/webp"] },
};

export default nextConfig;
