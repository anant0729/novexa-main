"use client";

import { motion, useInView } from "framer-motion";
import Image from "next/image";
import { useRef } from "react";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.07 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.45, ease: [0.22, 1, 0.36, 1] as const },
  },
};

export default function About() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="about" className="bg-white py-14 text-[#0a0f1a] sm:py-20 lg:py-24">
      <div className="mx-auto max-w-6xl px-6 lg:px-8">
        <div ref={ref} className="space-y-10">
          <motion.div initial="hidden" animate={isInView ? "visible" : "hidden"} variants={containerVariants} className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
            <motion.div variants={itemVariants} className="max-w-2xl">
              <p className="text-[1.05rem] font-semibold uppercase tracking-[0.2em] text-[#4a7fa5]">About Us</p>
              <h2 className="mt-4 text-3xl font-semibold tracking-tight text-[#0a0f1a] md:text-4xl">
                Building brands that stay memorable.
              </h2>
              <p className="mt-5 text-lg leading-8 text-[#5f6b80]">
                We are a leading provider of branding, printing, retail branding, POSM manufacturing, corporate gifting, promotional products and event activation solutions.
              </p>
              <p className="mt-4 text-lg leading-8 text-[#5f6b80]">
                We help businesses enhance their brand visibility through innovative, high-quality and cost-effective marketing solutions across India.
              </p>
            </motion.div>
            <motion.div variants={itemVariants} className="rounded-2xl border border-[#e6ebf3] bg-[#f8f9fb] p-6 shadow-sm sm:p-8">
              <p className="text-[0.7rem] font-semibold uppercase tracking-[0.2em] text-[#4a7fa5]">Vision</p>
              <p className="mt-3 text-[15px] leading-7 text-[#0a0f1a]">
                To become India&apos;s most trusted branding and marketing solutions company by delivering innovative and customer-focused services.
              </p>
              <p className="mt-6 text-[0.7rem] font-semibold uppercase tracking-[0.2em] text-[#4a7fa5]">Mission</p>
              <p className="mt-3 text-[15px] leading-7 text-[#0a0f1a]">
                Deliver premium quality solutions, ensure timely execution, build long-term client relationships and create impactful brand experiences.
              </p>
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="grid grid-cols-1 gap-4 sm:grid-cols-2"
          >
            <div className="relative aspect-[16/10] overflow-hidden rounded-2xl border border-[#e6ebf3] shadow-sm">
              <Image
                src="/about/office-1.jpg"
                alt="Novexa Global office - Logix Technova, Noida"
                fill
                sizes="(max-width: 768px) 100vw, 50vw"
                className="object-cover"
              />
            </div>
            <div className="relative aspect-[16/10] overflow-hidden rounded-2xl border border-[#e6ebf3] shadow-sm">
              <Image
                src="/about/office-2.jpg"
                alt="Novexa Global office building"
                fill
                sizes="(max-width: 768px) 100vw, 50vw"
                className="object-cover"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
