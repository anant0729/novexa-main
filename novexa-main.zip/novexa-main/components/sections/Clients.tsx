"use client";

import Image from "next/image";
import { useRef, useState } from "react";

type ClientLogo = {
  name: string;
  src: string;
};

const clients: ClientLogo[] = [
  { name: "Kohler", src: "/logos/kohler.png" },
  { name: "Globus Spirits", src: "/logos/globus-spirits.png" },
  { name: "Dish TV", src: "/logos/dish-tv.png" },
  { name: "NDTV", src: "/logos/ndtv.png" },
  { name: "News18 Hindi", src: "/logos/news18-hindi.png" },
  { name: "Sparsh Pearl", src: "/logos/sparsh-pearl.png" },
  { name: "The Muthoot Group", src: "/logos/muthoot-group.png" },
  { name: "BharatPe", src: "/logos/bharatpe.png" },
  { name: "Sonalika International", src: "/logos/sonalika-international.png" },
  { name: "Adani", src: "/logos/adani.png" },
];

export default function Clients() {
  const trackRef = useRef<HTMLDivElement>(null);
  const loop = [...clients, ...clients];

  return (
    <section aria-label="Our Clients" className="overflow-hidden bg-white py-14 text-[#0a0f1a] sm:py-20 lg:py-24">
      <div className="mx-auto max-w-6xl px-6 lg:px-8">
        <div className="max-w-3xl">
          <p className="text-[1.05rem] font-semibold uppercase tracking-[0.35em] text-[#4a7fa5]">
            Our Clients
          </p>
          <h2 className="mt-4 text-3xl font-semibold tracking-tight text-[#0a0f1a] md:text-4xl">
            Trusted by India&apos;s Leading Brands.
          </h2>
          <p className="mt-4 text-base leading-7 text-[#5f6b80] md:text-lg">
            From FMCG giants to media houses - our work speaks across industries.
          </p>
        </div>
      </div>

      <div
        className="group/track relative mt-10 [mask-image:linear-gradient(to_right,transparent,black_5%,black_95%,transparent)]"
        onMouseEnter={() => trackRef.current?.style.setProperty("animation-play-state", "paused")}
        onMouseLeave={() => trackRef.current?.style.setProperty("animation-play-state", "running")}
      >
        <div
          ref={trackRef}
          className="flex w-max gap-4 px-6 [animation:clients-scroll_32s_linear_infinite] lg:px-8"
        >
          {loop.map((client, i) => (
            <div
              key={`${client.name}-${i}`}
              className="group aspect-[3/2] w-[200px] shrink-0 overflow-hidden rounded-xl border border-[#e6ebf3] bg-[#f8f9fb] shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-[#d7e0ee] hover:shadow-md sm:w-[220px]"
            >
              <ClientCard client={client} />
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes clients-scroll {
          from { transform: translateX(0); }
          to { transform: translateX(-50%); }
        }
      `}</style>
    </section>
  );
}

function ClientCard({ client }: { client: ClientLogo }) {
  const [imageError, setImageError] = useState(false);

  return (
    <div className="relative flex h-full w-full items-center justify-center p-4">
      {!imageError ? (
        <Image
          src={client.src}
          alt={client.name}
          fill
          sizes="220px"
          className="object-contain p-4"
          onError={() => setImageError(true)}
        />
      ) : (
        <div className="text-center text-xs font-medium text-[#5b6477]">{client.name}</div>
      )}
    </div>
  );
}
