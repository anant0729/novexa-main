"use client";

import { Hero as HeroInner } from "@/components/hero/Hero";

export default function Hero() {
  return <HeroInner />;
}
