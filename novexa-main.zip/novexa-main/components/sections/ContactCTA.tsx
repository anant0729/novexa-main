"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, MessageCircle } from "lucide-react";
import { buttonVariants } from "@/components/ui/button";
import { Magnetic } from "@/components/ui/Magnetic";

const WHATSAPP =
  "https://wa.me/919818747929?text=" +
  encodeURIComponent("Hi Novexa, I'd like to discuss branding and marketing solutions for my brand.");

export function ContactCTA() {
  return (
    <section id="contact" className="relative overflow-hidden border-t border-[#e6ebf3] bg-[#f8f9fb] py-[clamp(64px,9vw,120px)] text-center">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-80px" }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="relative mx-auto max-w-[1200px] px-7"
      >
        {/* <span className="kicker blue">// Start a Conversation</span> */}
        <h2 className="heading mx-auto mt-[18px] mb-[18px] max-w-[760px] text-[clamp(28px,4vw,44px)] text-[var(--color-blue-deep)]">
          Tell us what you need to build.
        </h2>
        <p className="mx-auto mb-8 max-w-[480px] text-[17px] leading-relaxed text-[var(--color-muted)]">
          Get a tailored plan - scope, indicative pricing and timelines - for your brand. We reply
          within one business day.
        </p>

        <div className="flex flex-wrap justify-center gap-3">
          <Magnetic>
            <Link href="/contact" className={`${buttonVariants({ variant: "primary" })} group`}>
              Get a Quote
              <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
            </Link>
          </Magnetic>
          <a
            href={WHATSAPP}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex h-[46px] items-center justify-center gap-2 rounded-xl bg-[#25D366] px-[22px] font-[family-name:var(--font-display)] text-[15px] font-semibold text-white shadow-[0_2px_10px_rgba(37,211,102,0.32)] transition-[transform,box-shadow] duration-200 ease-[cubic-bezier(0.22,1,0.36,1)] hover:shadow-[0_8px_26px_rgba(37,211,102,0.40)] active:scale-[0.98]"
          >
            <MessageCircle className="h-4 w-4" />
            Chat on WhatsApp
          </a>
        </div>

        <p className="mt-5 font-[family-name:var(--font-mono)] text-[11.5px] tracking-[0.06em] text-[var(--color-muted)]">
          ~FAST RESPONSE · YOUR DETAILS STAY PRIVATE · NO OBLIGATION
        </p>
      </motion.div>
    </section>
  );
}
