"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";

const STEPS = [
  { n: 1, title: "Brief", body: "We learn your brand, goals, scale and timelines." },
  { n: 2, title: "Design", body: "Concepts and specs tailored to your identity and budget." },
  { n: 3, title: "Produce", body: "In-house manufacturing and printing, quality-checked at every stage." },
  { n: 4, title: "Approve", body: "Samples and sign-off before full-scale production." },
  { n: 5, title: "Install", body: "Rollout and installation, managed PAN India to your last outlet." },
];

export function Process() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="process" className="bg-[var(--color-navy)] py-[clamp(72px,11vw,140px)] text-white">
      <div className="mx-auto max-w-[1200px] px-7">
        <div className="mb-[54px] max-w-[620px]">
          <span className="kicker">// The Process</span>
          <h2 className="heading mt-4 text-[clamp(28px,3.6vw,46px)] text-white">
            A clear path from brief to installed.
          </h2>
        </div>

        <div ref={ref} className="relative mt-8">
          {/* connecting route line (desktop) */}
          <div className="absolute left-[6%] right-[6%] top-[21px] hidden h-[2px] overflow-hidden rounded-full bg-white/10 md:block">
            <motion.span
              className="absolute inset-y-0 left-0 block bg-gradient-to-r from-[var(--color-blue-int)] to-[var(--color-orange)]"
              initial={{ width: 0 }}
              animate={inView ? { width: "100%" } : {}}
              transition={{ duration: 1.6, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
            />
          </div>

          <div className="grid grid-cols-1 gap-7 md:grid-cols-5 md:gap-[18px]">
            {STEPS.map((s, i) => {
              const isLast = i === STEPS.length - 1;
              return (
                <motion.div
                  key={s.n}
                  initial={{ opacity: 0, y: 18 }}
                  animate={inView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.15 + i * 0.12, ease: [0.22, 1, 0.36, 1] }}
                  className="relative"
                >
                  <div
                    className={[
                      "relative z-[2] mb-[18px] grid h-[44px] w-[44px] place-items-center rounded-full font-[family-name:var(--font-display)] font-semibold transition-all duration-500",
                      isLast
                        ? "bg-[var(--color-orange)] text-[#1a1205] shadow-[0_0_0_6px_rgba(243,154,30,.16)]"
                        : "bg-[var(--color-blue)] text-white",
                    ].join(" ")}
                  >
                    {s.n}
                  </div>
                  <h4 className="heading mb-[7px] text-[17px] text-white">{s.title}</h4>
                  <p className="text-[13.5px] leading-[1.5] text-[rgba(233,238,247,.62)]">{s.body}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
