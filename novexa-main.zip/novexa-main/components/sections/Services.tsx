"use client";

import { motion, useInView } from "framer-motion";
import { ShoppingCart, Building2, MonitorPlay, ShoppingBag, Gift, Printer, UsersRound, Megaphone, LayoutGrid } from "lucide-react";
import { useRef } from "react";

const services = [
  { icon: ShoppingCart, title: "POSM Solutions" },
  { icon: Printer, title: "Printing & Packaging" },
  { icon: Building2, title: "Retail, Indoor & Outdoor Branding" },
  { icon: MonitorPlay, title: "Custom Display Units" },
  { icon: ShoppingBag, title: "Influencer Marketing & Campaigns" },
  { icon: LayoutGrid, title: "Event & Campaign Activations" },
  { icon: Printer, title: "Brand Partnerships & Collaborations" },
  { icon: UsersRound, title: "Social Strategy & Content Creation" },
  { icon: Megaphone, title: "Online Reputation Management (ORM)" },
  { icon: Gift, title: "Corporate Gifting" },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.07 } },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.45, ease: [0.22, 1, 0.36, 1] as const },
  },
};

export default function Services() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="services" className="bg-white py-14 text-[#0a0f1a] sm:py-20 lg:py-24">
      <div className="mx-auto max-w-6xl px-6 lg:px-8">
        <div ref={ref} className="space-y-8">
          <div className="max-w-2xl">
            <p className="text-[1.05rem] font-semibold uppercase tracking-[0.2em] text-[#4a7fa5]">Our Services</p>
            <h2 className="mt-4 text-3xl font-semibold tracking-tight text-[#0a0f1a] md:text-4xl">From strategy to execution, we cover every touchpoint.</h2>
          </div>
          <motion.div initial="hidden" animate={isInView ? "visible" : "hidden"} variants={containerVariants} className="grid grid-cols-2 gap-4 md:grid-cols-5">
            {services.map(({ icon: Icon, title }, index) => (
              <motion.div key={title} variants={itemVariants} className="rounded-2xl border border-[#e6ebf3] bg-[#f8f9fb] p-6 text-center shadow-sm">
                <div className={`mx-auto flex h-14 w-14 items-center justify-center rounded-full ${index % 2 === 0 ? "bg-[#1e3a5f] text-white" : "bg-[#f97316] text-white"}`}>
                  <Icon className="h-6 w-6" />
                </div>
                <h3 className="mt-4 text-sm font-semibold text-[#0a0f1a]">{title}</h3>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
