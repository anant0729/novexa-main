"use client";

import { useState } from "react";
import { motion, AnimatePresence, useInView } from "framer-motion";
import Image from "next/image";
import { useRef } from "react";
import { Printer, ShoppingCart, Store, PartyPopper, Gift } from "lucide-react";

type WorkItem = { label: string; src: string };

const CATEGORIES: { key: string; label: string; icon: typeof Printer; items: WorkItem[] }[] = [
  {
    key: "printing",
    label: "Printing",
    icon: Printer,
    items: [
      { label: "Brochures", src: "/printing/brochures.jpg" },
      { label: "Flyers", src: "/printing/flyers.jpg" },
      { label: "Catalogues", src: "/printing/catalogues.jpg" },
      { label: "Posters", src: "/printing/posters.jpg" },
      { label: "Danglers", src: "/printing/danglers.jpg" },
      { label: "Stickers", src: "/printing/stickers.jpg" },
      { label: "Labels", src: "/printing/labels.jpg" },
      { label: "Packaging Boxes", src: "/printing/packaging-boxes.jpg" },
      { label: "Visiting Cards", src: "/printing/visiting-cards.jpg" },
      { label: "Promotional Materials", src: "/printing/promotional-materials.jpg" },
    ],
  },
  {
    key: "posm",
    label: "POSM",
    icon: ShoppingCart,
    items: [
      { label: "Counter Top Units", src: "/posm/counter-top.jpg" },
      { label: "Floor Display Units", src: "/posm/floor-display.jpg" },
      { label: "Acrylic Display", src: "/posm/acrylic-display.jpg" },
      { label: "Metal Display", src: "/posm/metal-display.jpg" },
      { label: "MDF Display", src: "/posm/mdf-display.jpg" },
      { label: "Standees", src: "/posm/standees.jpg" },
      { label: "Canopies", src: "/posm/canopies.jpg" },
      { label: "Display Racks", src: "/posm/display-racks.jpg" },
      { label: "Product Display Units", src: "/posm/product-display-units.jpg" },
    ],
  },
  {
    key: "retail",
    label: "Retail & Store Branding",
    icon: Store,
    items: [
      { label: "Office Branding", src: "/retail/office-branding.jpg" },
      { label: "Wall Graphics", src: "/retail/wall-graphics.jpg" },
      { label: "Glass Branding", src: "/retail/glass-branding.jpg" },
      { label: "Reception Branding", src: "/retail/reception-branding.jpg" },
      { label: "Retail Branding", src: "/retail/retail-branding.jpg" },
      { label: "Showroom Branding", src: "/retail/showroom-branding.jpg" },
      { label: "Vehicle Branding", src: "/retail/vehicle-branding.jpg" },
      { label: "Mall Branding", src: "/retail/mall-branding.jpg" },
    ],
  },
  {
    key: "events",
    label: "Events & Activations",
    icon: PartyPopper,
    items: [
      { label: "Product Launch", src: "/events/product-launch.jpg" },
      { label: "Exhibition Stall", src: "/events/exhibition.jpg" },
      { label: "Road Shows", src: "/events/road-shows.jpg" },
      { label: "Mall Activation", src: "/events/mall-activation.jpg" },
    ],
  },
  {
    key: "gifting",
    label: "Corporate Gifting",
    icon: Gift,
    items: [
      { label: "Corporate Gifting", src: "/posm/counter-top.jpg" },
      { label: "Promotional Merchandise", src: "/printing/promotional-materials.jpg" },
      { label: "Customized Gifts", src: "/printing/visiting-cards.jpg" },
      { label: "Employee & Client Gifts", src: "/why-us/handshake.jpg" },
    ],
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.06 } },
};

const itemVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: [0.22, 1, 0.36, 1] as const } },
};

export default function OurWork() {
  const [active, setActive] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });
  const category = CATEGORIES[active];

  return (
    <section aria-label="Our Work" className="bg-[#f8f9fb] py-14 text-[#0a0f1a] sm:py-20 lg:py-24">
      <div className="mx-auto max-w-6xl px-6 lg:px-8">
        <div ref={ref} className="space-y-8">
          <div className="max-w-2xl">
            <p className="text-[1.05rem] font-semibold uppercase tracking-[0.2em] text-[#4a7fa5]">Our Work</p>
            <h2 className="mt-4 text-3xl font-semibold tracking-tight text-[#0a0f1a] md:text-4xl">
              Print, POSM, branding and gifting - delivered.
            </h2>
          </div>

          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((cat, i) => {
              const Icon = cat.icon;
              const on = i === active;
              return (
                <button
                  key={cat.key}
                  onClick={() => setActive(i)}
                  className={[
                    "inline-flex items-center gap-2 rounded-full border px-4 py-2.5 text-[14px] font-medium transition-all duration-200",
                    on
                      ? "border-[#1e3a5f] bg-[#1e3a5f] text-white shadow-[0_6px_18px_rgba(30,58,95,.25)]"
                      : "border-[#e6ebf3] bg-white text-[#5b6477] hover:border-[#1e3a5f] hover:text-[#0a0f1a]",
                  ].join(" ")}
                >
                  <Icon className="h-4 w-4" strokeWidth={1.7} />
                  {cat.label}
                </button>
              );
            })}
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={category.key}
              initial="hidden"
              animate={isInView ? "visible" : "hidden"}
              exit={{ opacity: 0 }}
              variants={containerVariants}
              className="grid grid-cols-2 gap-4 md:grid-cols-5"
            >
              {category.items.map((item) => (
                <motion.div
                  key={item.label}
                  variants={itemVariants}
                  className="overflow-hidden rounded-2xl border border-[#e6ebf3] bg-white shadow-sm"
                >
                  <div className="relative aspect-square w-full bg-[#1a2a42]">
                    <Image src={item.src} alt={item.label} fill sizes="(max-width: 768px) 50vw, 20vw" className="object-cover" />
                  </div>
                  <div className="bg-white px-3 py-3 text-center text-sm font-semibold text-[#0a0f1a]">{item.label}</div>
                </motion.div>
              ))}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
