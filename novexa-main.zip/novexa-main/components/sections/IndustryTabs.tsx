"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Tv, Landmark, ShoppingBag, Home, Wheat, Wallet, ArrowUpRight } from "lucide-react";

const ease = [0.22, 1, 0.36, 1] as const;

const INDUSTRIES = [
  {
    icon: Tv,
    name: "Media & Broadcasting",
    overview: "Studio, event and corporate branding for broadcasters and media houses that need to move fast without compromising finish.",
    challenges: ["Tight production timelines", "Multi-city consistency", "High-visibility standards"],
    categories: ["Studio & set branding", "Event signage", "Corporate gifting", "Promotional collateral"],
  },
  {
    icon: Landmark,
    name: "BFSI",
    overview: "Branch and office branding, promotional merchandise and event support for banks, NBFCs and financial services.",
    challenges: ["Compliance-safe branding", "PAN-India rollout consistency", "Fast branch turnarounds"],
    categories: ["Branch branding", "Corporate gifting", "POSM & standees", "Employee recognition kits"],
  },
  {
    icon: Home,
    name: "Sanitaryware & Consumer Durables",
    overview: "Showroom and retail branding, plus display units that hold up to daily footfall and handling.",
    challenges: ["Durable in-store displays", "Showroom brand consistency", "Multi-city dealer rollout"],
    categories: ["Showroom branding", "Display racks & units", "Dealer branding kits", "Product signage"],
  },
  {
    icon: Wallet,
    name: "Fintech",
    overview: "Fast-moving promotional and activation support for fintech brands scaling acquisition on the ground.",
    challenges: ["Rapid campaign turnaround", "City-by-city activation", "On-brand at scale"],
    categories: ["Mall & road show activations", "Promotional merchandise", "POSM & standees", "Corporate events"],
  },
  {
    icon: Wheat,
    name: "Agriculture & Industrial",
    overview: "Dealer and distributor branding for agri and industrial brands with a wide, dispersed network.",
    challenges: ["Wide dealer network coverage", "Durable outdoor branding", "Consistent regional rollout"],
    categories: ["Dealer signage", "Outdoor & vehicle branding", "Canopies & standees", "Promotional material"],
  },
  {
    icon: ShoppingBag,
    name: "Retail & FMCG",
    overview: "In-store branding and POSM built to convert footfall, from single outlets to national chains.",
    challenges: ["On-shelf visibility", "Rollout speed at scale", "Consistent quality across vendors"],
    categories: ["In-store POSM", "Retail branding", "Packaging & labels", "Promotional products"],
  },
];

export function IndustryTabs() {
  const [active, setActive] = useState(0);
  const a = INDUSTRIES[active];
  const Icon = a.icon;

  return (
    <main className="py-[clamp(64px,9vw,120px)]">
      <div className="mx-auto max-w-[1200px] px-7">
        {/* tabs */}
        <div className="flex flex-wrap gap-2">
          {INDUSTRIES.map((ind, i) => {
            const TabIcon = ind.icon;
            const on = i === active;
            return (
              <button
                key={ind.name}
                onClick={() => setActive(i)}
                className={[
                  "inline-flex items-center gap-2 rounded-full border px-4 py-2.5 text-[14px] font-medium transition-all duration-200",
                  on
                    ? "border-[var(--color-blue)] bg-[var(--color-blue)] text-white shadow-[0_6px_18px_rgba(35,75,133,.25)]"
                    : "border-[var(--color-line)] bg-white text-[var(--color-muted)] hover:border-[var(--color-blue-int)] hover:text-[var(--color-ink)]",
                ].join(" ")}
              >
                <TabIcon className="h-4 w-4" strokeWidth={1.7} />
                {ind.name}
              </button>
            );
          })}
        </div>

        {/* panel */}
        <AnimatePresence mode="wait">
          <motion.div
            key={active}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.35, ease }}
            className="mt-8 grid gap-px overflow-hidden rounded-3xl border border-[var(--color-line)] bg-[var(--color-line)] lg:grid-cols-[1.2fr_1fr]"
          >
            {/* left: overview + challenges */}
            <div className="bg-white p-8 sm:p-10">
              <div className="grid h-[52px] w-[52px] place-items-center rounded-2xl bg-[var(--color-blue-100)] text-[var(--color-blue)]">
                <Icon className="h-6 w-6" strokeWidth={1.6} />
              </div>
              <h2 className="heading mt-5 text-[clamp(24px,3vw,34px)] text-[var(--color-blue-deep)]">{a.name}</h2>
              <p className="mt-4 max-w-[480px] text-[16.5px] leading-relaxed text-[var(--color-muted)]">{a.overview}</p>

              <div className="mt-8">
                <div className="kicker blue mb-4">Common challenges we solve</div>
                <ul className="space-y-3">
                  {a.challenges.map((c) => (
                    <li key={c} className="flex items-start gap-3 text-[15px] text-[var(--color-ink)]">
                      <span className="mt-2 h-[6px] w-[6px] shrink-0 rounded-full bg-[var(--color-orange)]" />
                      {c}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* right: sample categories */}
            <div className="bg-[#f8f9fb] p-8 sm:p-10">
              <div className="kicker blue mb-5">Sample categories</div>
              <div className="grid grid-cols-1 gap-3">
                {a.categories.map((cat) => (
                  <div
                    key={cat}
                    className="flex items-center justify-between rounded-xl border border-[var(--color-line)] bg-white px-4 py-3.5 text-[15px] text-[var(--color-ink)] shadow-sm transition-colors hover:border-[#d7e0ee]"
                  >
                    {cat}
                    <ArrowUpRight className="h-4 w-4 text-[var(--color-orange-deep)]" />
                  </div>
                ))}
              </div>
              <p className="mt-6 text-[13.5px] leading-relaxed text-[var(--color-muted)]">
                Don&apos;t see your sector? We work across categories - tell us what you need branded
                and where.
              </p>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </main>
  );
}
