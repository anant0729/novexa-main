"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Mail, Phone, MessageCircle, MapPin, Check, ArrowRight, ArrowLeft, Sparkles, Clock3 } from "lucide-react";
import { buttonVariants } from "@/components/ui/button";

const ease = [0.22, 1, 0.36, 1] as const;

const SERVICES = ["Branding", "Printing", "POSM", "Corporate Gifting", "Events & Activations", "Not sure yet"];
const REGIONS = ["Delhi NCR", "North India", "Pan India", "International", "Not sure"];
const VOLUMES = ["0-100", "500-1000", "1000-5000", "5000-20000", "Custom"];
const TIMELINES = ["ASAP", "1–2 weeks", "2–4 weeks", "Exploring"];
const MAX_SPEC_WORDS = 200;

const WHATSAPP = "https://wa.me/919818747929?text=" + encodeURIComponent("Hi Novexa, I'd like to discuss branding and marketing solutions for my brand.");
const MAP_SRC = "https://www.google.com/maps?q=B-321,+Plot+No-4,+Logix+Technova,+Sector-132,+Noida-201304&output=embed";

type Data = {
  service: string;
  product: string;
  region: string;
  specs: string;
  volume: string;
  customVolume: string;
  timeline: string;
  name: string;
  company: string;
  email: string;
  phone: string;
};
const EMPTY: Data = {
  service: "",
  product: "",
  region: "",
  specs: "",
  volume: "",
  customVolume: "",
  timeline: "",
  name: "",
  company: "",
  email: "",
  phone: "",
};

function wordCount(text: string) {
  const trimmed = text.trim();
  return trimmed ? trimmed.split(/\s+/).length : 0;
}

function Chip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={[
        "rounded-full border px-4 py-2.5 text-[14px] font-medium transition-all duration-200",
        active
          ? "border-[#f97316] bg-[#f97316] text-white shadow-[0_8px_18px_rgba(249,115,22,0.2)]"
          : "border-[#e6ebf3] bg-white text-[#5b6477] hover:border-[#1e3a5f] hover:text-[#0a1628]",
      ].join(" ")}
    >
      {label}
    </button>
  );
}

const inputCls =
  "h-12 w-full rounded-xl border border-[#e6ebf3] bg-[#f8f9fb] px-4 text-[15px] text-[#0a1628] outline-none transition-all placeholder:text-[#5b6477]/70 focus:border-[#1e3a5f] focus:bg-white focus:ring-2 focus:ring-[#1e3a5f]/15";

export function ContactBody() {
  const [step, setStep] = useState(0);
  const [data, setData] = useState<Data>(EMPTY);
  const [sent, setSent] = useState(false);
  const set = (k: keyof Data, v: string) => setData((d) => ({ ...d, [k]: v }));

  const specWords = wordCount(data.specs);
  const setSpecs = (v: string) => {
    if (wordCount(v) <= MAX_SPEC_WORDS) set("specs", v);
  };

  const canNext = step === 0 ? !!data.service : step === 1 ? !!data.region : true;
  const canSend = !!data.name && /\S+@\S+\.\S+/.test(data.email);
  const progressLabel = useMemo(() => {
    if (step === 0) return "Tell us where to begin";
    if (step === 1) return "Share the scale";
    return "Add your details";
  }, [step]);

  async function submit() {
    // Wire this to the FastAPI backend, e.g.:
    // await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/leads`, {
    //   method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data),
    // });
    setSent(true);
  }

  return (
    <main className="bg-[#f8f9fb] py-[clamp(56px,8vw,110px)]">
      <div className="mx-auto grid max-w-[1200px] gap-[18px] px-7 lg:grid-cols-[1.25fr_.85fr]">
        {/* ---------- form ---------- */}
        <div className="rounded-[28px] border border-[#e6ebf3] bg-white p-7 shadow-[0_20px_55px_rgba(10,22,40,0.06)] sm:p-10">
          {sent ? (
            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="py-10 text-center">
              <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-[var(--color-blue-100)] text-[var(--color-blue)]">
                <Check className="h-7 w-7" strokeWidth={2.2} />
              </div>
              <h2 className="heading mt-6 text-[24px] text-[var(--color-blue-deep)]">Request received.</h2>
              <p className="mx-auto mt-3 max-w-[380px] text-[15px] leading-relaxed text-[var(--color-muted)]">
                Our team will get back to you within one business day. Want to talk now?
              </p>
              <a
                href={WHATSAPP}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-6 inline-flex h-[46px] items-center justify-center gap-2 rounded-xl bg-[#25D366] px-[22px] font-[family-name:var(--font-display)] text-[15px] font-semibold text-white shadow-[0_2px_10px_rgba(37,211,102,0.32)] transition-[transform,box-shadow] duration-200 hover:shadow-[0_8px_26px_rgba(37,211,102,0.40)] active:scale-[0.98]"
              >
                <MessageCircle className="h-4 w-4" /> Chat on WhatsApp
              </a>
            </motion.div>
          ) : (
            <>
              {/* progress */}
              <div className="mb-7 rounded-2xl border border-[#e6ebf3] bg-[#f8f9fb] p-4">
                <div className="flex items-center justify-between font-[family-name:var(--font-mono)] text-[11px] uppercase tracking-[0.12em] text-[#5b6477]">
                  <span>Step {step + 1} of 3</span>
                  <span>{progressLabel}</span>
                </div>
                <div className="mt-3 h-[3px] overflow-hidden rounded-full bg-[#e6ebf3]">
                  <motion.div
                    className="h-full bg-gradient-to-r from-[#1e3a5f] via-[#234b85] to-[#f97316]"
                    animate={{ width: `${((step + 1) / 3) * 100}%` }}
                    transition={{ duration: 0.4, ease }}
                  />
                </div>
              </div>

              <AnimatePresence mode="wait">
                <motion.div
                  key={step}
                  initial={{ opacity: 0, x: 24 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -24 }}
                  transition={{ duration: 0.3, ease }}
                >
                  {step === 0 && (
                    <div>
                      <div className="flex items-center gap-2 text-[#4a7fa5]">
                        <Sparkles className="h-4 w-4" />
                        <span className="text-sm font-semibold uppercase tracking-[0.2em]">Start here</span>
                      </div>
                      <h2 className="heading mt-2 text-[22px] text-[#0a1628]">What do you need help with?</h2>
                      <div className="mt-5 flex flex-wrap gap-2">
                        {SERVICES.map((s) => (
                          <Chip key={s} label={s} active={data.service === s} onClick={() => set("service", s)} />
                        ))}
                      </div>
                      <label className="mt-7 block text-[13px] font-medium text-[var(--color-muted)]">
                        What are you looking to build? (optional)
                      </label>
                      <input
                        className={`${inputCls} mt-2`}
                        placeholder="e.g. retail branding, POSM units, event activation…"
                        value={data.product}
                        onChange={(e) => set("product", e.target.value)}
                      />
                    </div>
                  )}

                  {step === 1 && (
                    <div className="space-y-7">
                      <div>
                        <div className="flex items-center gap-2 text-[#4a7fa5]">
                        <Clock3 className="h-4 w-4" />
                        <span className="text-sm font-semibold uppercase tracking-[0.2em]">Execution planning</span>
                      </div>
                      <h2 className="heading mt-2 text-[22px] text-[#0a1628]">Where and how much?</h2>
                        <label className="mt-5 block text-[13px] font-medium text-[var(--color-muted)]">Rollout region</label>
                        <div className="mt-2 flex flex-wrap gap-2">
                          {REGIONS.map((r) => (
                            <Chip key={r} label={r} active={data.region === r} onClick={() => set("region", r)} />
                          ))}
                        </div>
                      </div>
                      <div>
                        <div className="flex items-center justify-between">
                          <label className="block text-[13px] font-medium text-[var(--color-muted)]">
                            Item & Specifications
                          </label>
                          <span className="font-[family-name:var(--font-mono)] text-[11px] text-[var(--color-muted)]">
                            {specWords}/{MAX_SPEC_WORDS} words
                          </span>
                        </div>
                        <textarea
                          className={`${inputCls} mt-2 h-28 resize-none py-3`}
                          placeholder="Describe the item, quantity, materials, dimensions or any other specifications…"
                          value={data.specs}
                          onChange={(e) => setSpecs(e.target.value)}
                        />
                      </div>
                      <div>
                        <label className="block text-[13px] font-medium text-[var(--color-muted)]">Order quantity</label>
                        <div className="mt-2 flex flex-wrap gap-2">
                          {VOLUMES.map((v) => (
                            <Chip key={v} label={v} active={data.volume === v} onClick={() => set("volume", v)} />
                          ))}
                        </div>
                        {data.volume === "Custom" && (
                          <input
                            className={`${inputCls} mt-3`}
                            type="number"
                            min={0}
                            placeholder="Enter exact quantity"
                            value={data.customVolume}
                            onChange={(e) => set("customVolume", e.target.value)}
                          />
                        )}
                      </div>
                      <div>
                        <label className="block text-[13px] font-medium text-[var(--color-muted)]">Timeline</label>
                        <div className="mt-2 flex flex-wrap gap-2">
                          {TIMELINES.map((t) => (
                            <Chip key={t} label={t} active={data.timeline === t} onClick={() => set("timeline", t)} />
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {step === 2 && (
                    <div>
                      <div className="flex items-center gap-2 text-[#4a7fa5]">
                        <Mail className="h-4 w-4" />
                        <span className="text-sm font-semibold uppercase tracking-[0.2em]">Your details</span>
                      </div>
                      <h2 className="heading mt-2 text-[22px] text-[#0a1628]">Where should we send your plan?</h2>
                      <div className="mt-5 grid gap-3 sm:grid-cols-2">
                        <input className={inputCls} placeholder="Full name *" value={data.name} onChange={(e) => set("name", e.target.value)} />
                        <input className={inputCls} placeholder="Company" value={data.company} onChange={(e) => set("company", e.target.value)} />
                        <input className={inputCls} type="email" placeholder="Work email *" value={data.email} onChange={(e) => set("email", e.target.value)} />
                        <input className={inputCls} placeholder="Phone / WhatsApp" value={data.phone} onChange={(e) => set("phone", e.target.value)} />
                      </div>
                      <p className="mt-4 font-[family-name:var(--font-mono)] text-[11px] tracking-[0.04em] text-[var(--color-muted)]">
                        YOUR DETAILS STAY PRIVATE · NO OBLIGATION
                      </p>
                    </div>
                  )}
                </motion.div>
              </AnimatePresence>

              {/* controls */}
              <div className="mt-8 flex items-center justify-between border-t border-[#e6ebf3] pt-6">
                <button
                  onClick={() => setStep((s) => Math.max(0, s - 1))}
                  className={`inline-flex items-center gap-1.5 text-[14px] font-medium text-[var(--color-muted)] transition-colors hover:text-[var(--color-ink)] ${step === 0 ? "invisible" : ""}`}
                >
                  <ArrowLeft className="h-4 w-4" /> Back
                </button>

                {step < 2 ? (
                  <button
                    disabled={!canNext}
                    onClick={() => setStep((s) => Math.min(2, s + 1))}
                    className={`${buttonVariants({ variant: "primary" })} disabled:cursor-not-allowed disabled:opacity-40`}
                  >
                    Continue <ArrowRight className="h-4 w-4" />
                  </button>
                ) : (
                  <button
                    disabled={!canSend}
                    onClick={submit}
                    className={`${buttonVariants({ variant: "primary" })} disabled:cursor-not-allowed disabled:opacity-40`}
                  >
                    Submit <ArrowRight className="h-4 w-4" />
                  </button>
                )}
              </div>
            </>
          )}
        </div>

        {/* ---------- info + map ---------- */}
        <div className="flex flex-col gap-[18px]">
          <div className="rounded-[28px] border border-[#e6ebf3] bg-white p-7 shadow-[0_20px_55px_rgba(10,22,40,0.06)]">
            {/* <span className="text-[1.05rem] font-semibold uppercase tracking-[0.2em] text-[#4a7fa5]"></span> */}
            <h3 className="mt-3 text-2xl font-semibold text-[#0a1628]">Let&apos;s build your brand together.</h3>
            <p className="mt-3 text-sm leading-7 text-[#5f6b80]">From concept to execution, our team helps you turn ideas into visible, memorable brand experiences.</p>
            <div className="mt-6 space-y-3">
              <a href="mailto:marketing@novexa-global.in" className="flex items-center gap-3 rounded-xl border border-[#e6ebf3] bg-[#f8f9fb] px-4 py-3 text-[15px] text-[#0a1628] transition hover:border-[#d7e0ee]">
                <Mail className="h-[18px] w-[18px] text-[#f97316]" strokeWidth={1.7} /> marketing@novexa-global.in
              </a>
              <a href="tel:+919818747929" className="flex items-center gap-3 rounded-xl border border-[#e6ebf3] bg-[#f8f9fb] px-4 py-3 text-[15px] text-[#0a1628] transition hover:border-[#d7e0ee]">
                <Phone className="h-[18px] w-[18px] text-[#f97316]" strokeWidth={1.7} /> +91 9818747929
              </a>
              <div className="flex items-start gap-3 rounded-xl border border-[#e6ebf3] bg-[#f8f9fb] px-4 py-3 text-[15px] text-[#5f6b80]">
                <MapPin className="mt-0.5 h-[18px] w-[18px] shrink-0 text-[#f97316]" strokeWidth={1.7} />
                B-321, Plot No-4, Logix Technova, Sector-132, Noida-201304
              </div>
            </div>
            <a
              href={WHATSAPP}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-6 inline-flex h-[46px] w-full items-center justify-center gap-2 rounded-xl bg-[#25D366] px-[22px] font-[family-name:var(--font-display)] text-[15px] font-semibold text-white shadow-[0_2px_10px_rgba(37,211,102,0.32)] transition-[transform,box-shadow] duration-200 hover:shadow-[0_8px_26px_rgba(37,211,102,0.40)] active:scale-[0.98]"
            >
              <MessageCircle className="h-4 w-4" /> Chat on WhatsApp
            </a>
          </div>

          <div className="overflow-hidden rounded-[28px] border border-[#e6ebf3] bg-white shadow-[0_20px_55px_rgba(10,22,40,0.06)]">
            <iframe
              title="Novexa Global office location"
              src={MAP_SRC}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="h-[280px] w-full border-0 grayscale-[.2]"
            />
          </div>
        </div>
      </div>
    </main>
  );
}
