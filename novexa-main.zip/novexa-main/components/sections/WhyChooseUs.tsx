"use client";

import { motion, useInView } from "framer-motion";
import Image from "next/image";
import { useRef } from "react";
import { Users, Lightbulb, ShieldCheck, Clock3, IndianRupee, MapPin, Layers3, CheckCircle2 } from "lucide-react";

const reasons = [
  { label: "Experienced & Professional Team", icon: Users },
  { label: "Creative & Innovative Solutions", icon: Lightbulb },
  { label: "Premium Quality Assurance", icon: ShieldCheck },
  { label: "Timely Delivery & On-Time Execution", icon: Clock3 },
  { label: "Competitive Pricing", icon: IndianRupee },
  { label: "PAN India Services", icon: MapPin },
  { label: "End-to-End Solutions", icon: Layers3 },
  { label: "100% Customer Satisfaction", icon: CheckCircle2 },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.07 } },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.45, ease: [0.22, 1, 0.36, 1] as const },
  },
};

export default function WhyChooseUs() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section aria-label="Why Choose Us" className="bg-white py-14 text-[#0a0f1a] sm:py-20 lg:py-24">
      <div className="mx-auto max-w-6xl px-6 lg:px-8">
        <div ref={ref} className="space-y-8">
          <div className="max-w-2xl">
            {/* <p className="text-[1.05rem] font-semibold uppercase tracking-[0.2em] text-[#4a7fa5]">// Why Choose Us</p> */}
            <h2 className="mt-4 text-3xl font-semibold tracking-tight text-[#0a0f1a] md:text-4xl">WHY CHOOSE NOVEXA GLOBAL?</h2>
          </div>
          <motion.div initial="hidden" animate={isInView ? "visible" : "hidden"} variants={containerVariants} className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
            <motion.div variants={itemVariants} className="space-y-4">
              {reasons.map(({ label, icon: Icon }) => (
                <div key={label} className="flex items-center gap-4 rounded-xl border border-[#e6ebf3] bg-[#f8f9fb] px-4 py-4">
                  <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#1e3a5f] text-[#f97316]">
                    <Icon className="h-5 w-5" />
                  </div>
                  <span className="text-base font-medium text-[#0a0f1a]">{label}</span>
                </div>
              ))}
            </motion.div>
            <motion.div variants={itemVariants} className="relative min-h-[420px] overflow-hidden rounded-3xl border border-[#e6ebf3] shadow-sm">
              <Image src="/why-us/handshake.jpg" alt="Handshake" fill sizes="(max-width: 1024px) 100vw, 40vw" className="object-cover" />
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
