"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import { Lightbulb, Cog, Target } from "lucide-react";

const ease = [0.22, 1, 0.36, 1] as const;
const reveal = {
  hidden: { opacity: 0, y: 20 },
  show: (i: number) => ({ opacity: 1, y: 0, transition: { duration: 0.55, delay: i * 0.07, ease } }),
};

const STATS = [
  ["6+", "Years operating"],
  ["100+", "Clients"],
  ["24+", "States covered"],
  ["500+", "Projects delivered"],
];

const VALUES = [
  { icon: Lightbulb, t: "Innovate", d: "Creative ideas that deliver, not just decorate." },
  { icon: Cog, t: "Execute", d: "Precision in every detail, from design to install." },
  { icon: Target, t: "Excel", d: "Exceeding client expectations, every rollout." },
];

const REGIONS = [
  { region: "North", places: "Delhi NCR · Punjab · Haryana · UP" },
  { region: "West", places: "Maharashtra · Gujarat · Rajasthan" },
  { region: "South", places: "Karnataka · Tamil Nadu · Telangana" },
  { region: "East", places: "West Bengal · Odisha · Bihar" },
];

function Block({ children, i = 0 }: { children: React.ReactNode; i?: number }) {
  return (
    <motion.div variants={reveal} custom={i} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-60px" }}>
      {children}
    </motion.div>
  );
}

export function AboutBody() {
  return (
    <main>
      {/* story + stats */}
      <section className="py-[clamp(64px,9vw,120px)]">
        <div className="mx-auto max-w-[1200px] px-7">
          <div className="grid gap-12 lg:grid-cols-[1.3fr_1fr]">
            <Block>
              <span className="kicker blue">Our Story</span>
              <h2 className="heading mt-4 text-[clamp(26px,3.2vw,40px)] text-[var(--color-blue-deep)]">
                A leading provider of branding, printing and POSM solutions across India.
              </h2>
              <div className="mt-5 space-y-4 text-[16.5px] leading-relaxed text-[var(--color-muted)]">
                <p>
                  Novexa Global is a branding, printing, retail branding, POSM manufacturing,
                  corporate gifting, promotional products and event activation company. We started
                  with a simple observation: brands don&apos;t lose visibility because the idea was
                  weak - they lose it in execution, in the gap between a design and a finished
                  display, between a brief and a nationwide rollout.
                </p>
                <p>
                  We exist to close that gap. We help businesses enhance their brand visibility
                  through innovative, high-quality and cost-effective marketing solutions, designed,
                  manufactured and installed by one accountable team, across PAN India.
                </p>
              </div>
            </Block>

            <Block i={1}>
              <div className="relative aspect-[4/3] overflow-hidden rounded-2xl border border-[var(--color-line)]">
                <Image
                  src="/about/office-1.jpg"
                  alt="Novexa Global office - Logix Technova, Noida"
                  fill
                  sizes="(max-width: 1024px) 100vw, 40vw"
                  className="object-cover"
                />
              </div>
            </Block>
          </div>

          <div className="mt-10 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-[var(--color-line)] bg-[var(--color-line)]">
            {STATS.map(([n, l]) => (
              <div key={l} className="bg-white p-7">
                <div className="tnum heading text-[clamp(28px,3vw,38px)] text-[var(--color-blue)]">{n}</div>
                <div className="mt-2 font-[family-name:var(--font-mono)] text-[11px] uppercase tracking-[0.1em] text-[var(--color-muted)]">
                  {l}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* mission / vision / values */}
      <section className="bg-white py-[clamp(64px,9vw,120px)]">
        <div className="mx-auto max-w-[1200px] px-7">
          <div className="grid gap-10 md:grid-cols-2">
            <Block>
              <div className="kicker blue mb-3">Vision</div>
              <p className="text-[19px] leading-relaxed text-[var(--color-ink)]">
                To become India&apos;s most trusted branding and marketing solutions company by
                delivering innovative and customer-focused services.
              </p>
            </Block>
            <Block i={1}>
              <div className="kicker blue mb-3">Mission</div>
              <p className="text-[19px] leading-relaxed text-[var(--color-ink)]">
                Deliver premium quality solutions, ensure timely execution, build long-term client
                relationships and create impactful brand experiences.
              </p>
            </Block>
          </div>

          <div className="mt-14">
            <Block>
              <span className="kicker blue">What We Stand For</span>
            </Block>
            <div className="mt-6 grid grid-cols-1 gap-[14px] sm:grid-cols-3">
              {VALUES.map(({ icon: Icon, t, d }, i) => (
                <Block key={t} i={i}>
                  <div className="h-full rounded-2xl border border-[var(--color-line)] bg-[var(--color-off)] p-6">
                    <Icon className="h-6 w-6 text-[var(--color-orange)]" strokeWidth={1.6} />
                    <h3 className="heading mt-4 text-[17px] text-[var(--color-blue-deep)]">{t}</h3>
                    <p className="mt-2 text-[14px] leading-[1.5] text-[var(--color-muted)]">{d}</p>
                  </div>
                </Block>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* our office */}
      <section className="py-[clamp(64px,9vw,120px)]">
        <div className="mx-auto max-w-[1200px] px-7">
          <div className="grid gap-10 lg:grid-cols-[1fr_1.3fr] lg:items-center">
            <Block>
              <span className="kicker blue">Our Office</span>
              <h2 className="heading mt-4 text-[clamp(24px,3vw,36px)] text-[var(--color-blue-deep)]">
                Headquartered in Logix Technova, Noida.
              </h2>
              <p className="mt-4 max-w-[420px] text-[16px] leading-relaxed text-[var(--color-muted)]">
                B-321, Plot No-4, Logix Technova, Sector-132, Noida 201304: our production and
                client servicing hub for PAN-India rollouts.
              </p>
            </Block>
            <Block i={1}>
              <div className="relative aspect-[16/10] overflow-hidden rounded-2xl border border-[var(--color-line)]">
                <Image
                  src="/about/office-2.jpg"
                  alt="Novexa Global office building"
                  fill
                  sizes="(max-width: 1024px) 100vw, 55vw"
                  className="object-cover"
                />
              </div>
            </Block>
          </div>
        </div>
      </section>

      {/* PAN-India reach */}
      <section className="bg-[#f8f9fb] py-[clamp(64px,9vw,120px)]">
        <div className="mx-auto max-w-[1200px] px-7">
          <Block>
            <span className="kicker blue">PAN India Reach</span>
            <h2 className="heading mt-4 max-w-[640px] text-[clamp(26px,3.2vw,40px)] text-[var(--color-blue-deep)]">
              Execution capability across every major region in India.
            </h2>
          </Block>
          <div className="mt-10 grid grid-cols-1 gap-px overflow-hidden rounded-2xl border border-[var(--color-line)] bg-[var(--color-line)] sm:grid-cols-2 lg:grid-cols-4">
            {REGIONS.map((r, i) => (
              <Block key={r.region} i={i}>
                <div className="h-full bg-white p-7">
                  <div className="font-[family-name:var(--font-mono)] text-[11px] uppercase tracking-[0.12em] text-[var(--color-orange-deep)]">
                    {r.region}
                  </div>
                  <p className="mt-3 text-[15px] leading-relaxed text-[var(--color-muted)]">{r.places}</p>
                </div>
              </Block>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
