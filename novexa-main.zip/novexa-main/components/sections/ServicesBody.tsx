"use client";

import { motion } from "framer-motion";
import {
  ShoppingCart,
  Printer,
  Building2,
  MonitorPlay,
  ShoppingBag,
  LayoutGrid,
  Megaphone,
  UsersRound,
  Gift,
  Check,
} from "lucide-react";

export const SERVICES = [
  {
    icon: ShoppingCart,
    slug: "posm-solutions",
    title: "POSM Solutions",
    body: "Point-of-sale materials designed and manufactured to convert footfall, from single outlets to national chains.",
    includes: ["Counter-top & floor display units", "Acrylic, metal & MDF displays", "Standees, canopies & racks"],
    pairsWith: ["retail-indoor-outdoor-branding", "custom-display-units", "printing-packaging", "events-activations"],
  },
  {
    icon: Printer,
    slug: "printing-packaging",
    title: "Printing & Packaging",
    body: "Premium print production for every touchpoint, from brochures to retail-ready packaging.",
    includes: ["Brochures, flyers & catalogues", "Labels & packaging boxes", "Visiting cards & promo material"],
    pairsWith: ["posm-solutions", "corporate-gifting", "retail-indoor-outdoor-branding", "brand-partnerships"],
  },
  {
    icon: Building2,
    slug: "retail-indoor-outdoor-branding",
    title: "Retail, Indoor & Outdoor Branding",
    body: "Office, showroom, mall and vehicle branding that puts your identity in front of the people who matter.",
    includes: ["Office & reception branding", "Showroom & mall branding", "Wall graphics & glass branding"],
    pairsWith: ["posm-solutions", "custom-display-units", "printing-packaging", "events-activations"],
  },
  {
    icon: MonitorPlay,
    slug: "custom-display-units",
    title: "Custom Display Units",
    body: "Bespoke display and fixture design for brands that need something off the standard catalogue.",
    includes: ["Concept design & prototyping", "Material selection & fabrication", "PAN-India installation"],
    pairsWith: ["posm-solutions", "retail-indoor-outdoor-branding", "events-activations", "printing-packaging"],
  },
  {
    icon: ShoppingBag,
    slug: "influencer-marketing",
    title: "Influencer Marketing & Campaigns",
    body: "Creator partnerships that put your brand in front of the right audience, backed by clear reporting.",
    includes: ["Creator sourcing & vetting", "Campaign planning & briefs", "Performance tracking & reporting"],
    pairsWith: ["social-strategy-content", "events-activations", "orm", "brand-partnerships"],
  },
  {
    icon: LayoutGrid,
    slug: "events-activations",
    title: "Event & Campaign Activations",
    body: "Product launches, road shows and mall activations planned and executed end to end.",
    includes: ["Product launches", "Road shows & mall activations", "Exhibition stalls & corporate events"],
    pairsWith: ["posm-solutions", "retail-indoor-outdoor-branding", "influencer-marketing", "corporate-gifting"],
  },
  {
    icon: Printer,
    slug: "brand-partnerships",
    title: "Brand Partnerships & Collaborations",
    body: "Co-branded initiatives and strategic tie-ups that expand your reach without diluting your identity.",
    includes: ["Partner identification", "Co-branded campaign design", "Contract & execution support"],
    pairsWith: ["influencer-marketing", "events-activations", "social-strategy-content", "printing-packaging"],
  },
  {
    icon: UsersRound,
    slug: "social-strategy-content",
    title: "Social Strategy & Content Creation",
    body: "A content engine built around your brand voice, planned and produced for consistent output.",
    includes: ["Content calendars & strategy", "Photo & video production", "Copywriting & captions"],
    pairsWith: ["influencer-marketing", "orm", "brand-partnerships", "events-activations"],
  },
  {
    icon: Megaphone,
    slug: "orm",
    title: "Online Reputation Management",
    body: "Active monitoring and response so your brand's online presence stays accurate and trustworthy.",
    includes: ["Review & mention monitoring", "Response management", "Sentiment reporting"],
    pairsWith: ["social-strategy-content", "influencer-marketing", "brand-partnerships"],
  },
  {
    icon: Gift,
    slug: "corporate-gifting",
    title: "Corporate Gifting",
    body: "Premium, branded gifting that leaves a lasting impression on clients, partners and teams.",
    includes: ["Custom-branded merchandise", "Festive & milestone gifting", "Employee & client recognition"],
    pairsWith: ["printing-packaging", "events-activations", "posm-solutions", "retail-indoor-outdoor-branding"],
  },
];

const ease = [0.22, 1, 0.36, 1] as const;

export function ServicesBody() {
  return (
    <main className="py-[clamp(64px,9vw,120px)]">
      <div className="mx-auto max-w-[1200px] px-7">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.5, ease }}
          className="mb-12 max-w-[600px]"
        >
          <span className="kicker blue">Capabilities</span>
          <p className="mt-4 text-[17px] leading-relaxed text-[var(--color-muted)]">
            Ten services, one accountable partner - engage one, or hand us the entire brand
            execution.
          </p>
        </motion.div>

        <div id="all" className="grid grid-cols-1 gap-[18px] md:grid-cols-2">
          {SERVICES.map(({ icon: Icon, slug, title, body, includes, pairsWith }, i) => (
            <motion.div
              key={title}
              id={slug}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: (i % 2) * 0.06, ease }}
              className="group relative scroll-mt-28 overflow-hidden rounded-2xl border border-[var(--color-line)] bg-white p-8 transition-[transform,box-shadow,border-color] duration-300 hover:-translate-y-[4px] hover:border-[#d7e0ee] hover:shadow-[0_24px_56px_rgba(16,49,90,.12)]"
            >
              <span className="absolute inset-x-0 top-0 h-[2px] origin-left scale-x-0 bg-gradient-to-r from-[var(--color-orange)] to-[var(--color-orange-deep)] transition-transform duration-[450ms] group-hover:scale-x-100" />
              <div className="mb-5 grid h-[46px] w-[46px] place-items-center rounded-[12px] bg-[var(--color-blue-100)] text-[var(--color-blue)] transition-colors duration-300 group-hover:bg-[var(--color-blue)] group-hover:text-white">
                <Icon className="h-5 w-5" strokeWidth={1.6} />
              </div>
              <h2 className="heading text-[21px] text-[var(--color-blue-deep)]">{title}</h2>
              <p className="mt-3 text-[15px] leading-relaxed text-[var(--color-muted)]">{body}</p>
              <ul className="mt-5 space-y-2 border-t border-[var(--color-line)] pt-5">
                {includes.map((it) => (
                  <li key={it} className="flex items-center gap-2.5 text-[14px] text-[var(--color-ink)]">
                    <Check className="h-4 w-4 shrink-0 text-[var(--color-orange-deep)]" strokeWidth={2.2} />
                    {it}
                  </li>
                ))}
              </ul>
              {pairsWith && pairsWith.length > 0 && (
                <div className="mt-5 border-t border-[var(--color-line)] pt-5">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.1em] text-[var(--color-muted)]">
                    Pairs well with
                  </p>
                  <div className="mt-2.5 flex flex-wrap gap-1.5">
                    {pairsWith.map((s) => {
                      const svc = SERVICES.find((x) => x.slug === s);
                      if (!svc) return null;
                      return (
                        <a
                          key={s}
                          href={`#${s}`}
                          className="rounded-full border border-[var(--color-line)] px-2.5 py-1 text-[12px] text-[var(--color-blue-int)] transition-colors hover:border-[var(--color-blue-int)] hover:bg-[var(--color-blue-100)]"
                        >
                          {svc.title}
                        </a>
                      );
                    })}
                  </div>
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </main>
  );
}
