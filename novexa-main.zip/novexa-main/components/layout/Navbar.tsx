"use client";

import Link from "next/link";
import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Phone, Mail, ChevronDown } from "lucide-react";
import { buttonVariants } from "@/components/ui/button";
import { Magnetic } from "@/components/ui/Magnetic";
import { SERVICES } from "@/components/sections/ServicesBody";

const LINKS: [string, string][] = [
  ["Home", "/"],
  ["About Us", "/about"],
  ["Contact", "/contact"],
];

export function Navbar() {
  const [open, setOpen] = useState(false);
  const [showBar, setShowBar] = useState(true);
  const [servicesOpen, setServicesOpen] = useState(false);
  const [mobileServicesOpen, setMobileServicesOpen] = useState(false);
  const closeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const openServices = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    setServicesOpen(true);
  };
  const scheduleCloseServices = () => {
    closeTimer.current = setTimeout(() => setServicesOpen(false), 150);
  };

  useEffect(() => {
    let lastY = window.scrollY;
    const onScroll = () => {
      const y = window.scrollY;
      setShowBar(y < 8 || y < lastY);
      lastY = y;
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="fixed inset-x-0 top-0 z-50">
      <div
        className={`overflow-hidden bg-[#0a1628] text-white transition-[max-height] duration-300 ${showBar ? "max-h-12 sm:max-h-10" : "max-h-0"}`}
      >
        <div className="mx-auto flex max-w-[1400px] items-center justify-end gap-3 overflow-x-auto px-4 py-2 text-[11.5px] whitespace-nowrap sm:gap-6 sm:px-7 sm:text-[13px]">
          <a href="tel:+919818747929" className="flex items-center gap-1.5 text-[#c7d3e6] transition-colors hover:text-white">
            <Phone className="h-3.5 w-3.5 shrink-0" /> +91 9818747929
          </a>
          <a href="mailto:marketing@novexa-global.in" className="flex items-center gap-1.5 text-[#c7d3e6] transition-colors hover:text-white">
            <Mail className="h-3.5 w-3.5 shrink-0" /> marketing@novexa-global.in
          </a>
        </div>
      </div>

      <nav className="flex items-center justify-between border-b border-[#e6ebf3] bg-white px-5 py-3 sm:px-7">
        <Link href="/" className="group flex items-center gap-3 rounded-full px-2 py-2 transition-all duration-300 hover:bg-[#f8f9fb]">
          <Image src="/novexa-logo.png" alt="Novexa Global" width={260} height={70} className="h-[38px] w-auto sm:h-[46px]" priority />
        </Link>
        <div className="hidden items-center gap-[30px] md:flex">
          <Link
            href="/"
            className="text-[14.5px] font-medium text-[#5b6477] transition-all duration-200 hover:text-[#0a1628]"
          >
            Home
          </Link>

          <div className="relative" onMouseEnter={openServices} onMouseLeave={scheduleCloseServices}>
            <Link
              href="/services"
              className="flex items-center gap-1 text-[14.5px] font-medium text-[#5b6477] transition-all duration-200 hover:text-[#0a1628]"
            >
              Services
              <ChevronDown className={`h-3.5 w-3.5 transition-transform duration-200 ${servicesOpen ? "rotate-180" : ""}`} />
            </Link>

            <AnimatePresence>
              {servicesOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 8 }}
                  transition={{ duration: 0.15 }}
                  className="absolute left-1/2 top-full z-50 mt-3 w-[560px] -translate-x-1/2 rounded-2xl border border-[#e6ebf3] bg-white p-3 shadow-[0_24px_60px_rgba(10,22,40,0.14)]"
                >
                  <div className="grid grid-cols-2 gap-1">
                    {SERVICES.map(({ icon: Icon, slug, title }) => (
                      <Link
                        key={slug}
                        href={`/services#${slug}`}
                        onClick={() => setServicesOpen(false)}
                        className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13.5px] font-medium text-[#0a1628] transition-colors hover:bg-[#f8f9fb]"
                      >
                        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[var(--color-blue-100)] text-[var(--color-blue)]">
                          <Icon className="h-4 w-4" strokeWidth={1.7} />
                        </span>
                        {title}
                      </Link>
                    ))}
                  </div>
                  <Link
                    href="/services"
                    onClick={() => setServicesOpen(false)}
                    className="mt-2 flex items-center justify-center rounded-xl border-t border-[#e6ebf3] px-3 py-2.5 text-[13px] font-semibold text-[var(--color-orange-deep)] transition-colors hover:bg-[#f8f9fb]"
                  >
                    View all services
                  </Link>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {LINKS.slice(1).map(([label, href]) => (
            <Link
              key={href}
              href={href}
              className="text-[14.5px] font-medium text-[#5b6477] transition-all duration-200 hover:text-[#0a1628]"
            >
              {label}
            </Link>
          ))}
          <Magnetic strength={0.25}>
            <Link href="/contact" className={buttonVariants({ variant: "primary", size: "sm" })}>
              Get a Quote
            </Link>
          </Magnetic>
        </div>

        <button
          aria-label="Menu"
          onClick={() => setOpen((v) => !v)}
          className="text-[var(--color-ink)] md:hidden"
        >
          {open ? <X /> : <Menu />}
        </button>

        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              className="absolute inset-x-0 top-full border-b border-[var(--color-line)] bg-white p-6 md:hidden"
            >
              <div className="flex max-h-[70vh] flex-col gap-4 overflow-y-auto">
                <Link href="/" onClick={() => setOpen(false)} className="text-[var(--color-ink)]">
                  Home
                </Link>

                <div>
                  <div className="flex w-full items-center justify-between text-[var(--color-ink)]">
                    <Link href="/services" onClick={() => setOpen(false)} className="flex-1">
                      Services
                    </Link>
                    <button
                      aria-label="Toggle services submenu"
                      onClick={() => setMobileServicesOpen((v) => !v)}
                      className="p-1"
                    >
                      <ChevronDown className={`h-4 w-4 transition-transform duration-200 ${mobileServicesOpen ? "rotate-180" : ""}`} />
                    </button>
                  </div>
                  <AnimatePresence>
                    {mobileServicesOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden"
                      >
                        <div className="mt-3 flex flex-col gap-3 border-l border-[var(--color-line)] pl-4">
                          {SERVICES.map(({ slug, title }) => (
                            <Link
                              key={slug}
                              href={`/services#${slug}`}
                              onClick={() => setOpen(false)}
                              className="text-[14px] text-[var(--color-muted)]"
                            >
                              {title}
                            </Link>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {LINKS.slice(1).map(([label, href]) => (
                  <Link key={href} href={href} onClick={() => setOpen(false)} className="text-[var(--color-ink)]">
                    {label}
                  </Link>
                ))}
                <a href="tel:+919818747929" className="flex items-center gap-2 text-[var(--color-muted)]">
                  <Phone className="h-4 w-4" /> +91 9818747929
                </a>
                <a href="mailto:marketing@novexa-global.in" className="flex items-center gap-2 text-[var(--color-muted)]">
                  <Mail className="h-4 w-4" /> marketing@novexa-global.in
                </a>
                <Link href="/contact" onClick={() => setOpen(false)} className={buttonVariants({ variant: "primary" }) + " mt-2 w-full"}>
                  Get a Quote
                </Link>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>
    </div>
  );
}
