export function PageHero({
  kicker,
  title,
  subtitle,
}: {
  kicker: string;
  title: string;
  subtitle?: string;
}) {
  return (
    <header className="relative overflow-hidden border-b border-[#e6ebf3] bg-white pb-[clamp(48px,7vw,80px)] pt-[132px] sm:pt-[148px] lg:pt-[168px]">
      <div className="relative mx-auto max-w-[1200px] px-7">
        <span className="kicker blue">{kicker}</span>
        <h1 className="heading mt-4 max-w-[820px] text-[clamp(28px,3.8vw,44px)] text-[var(--color-blue-deep)]">{title}</h1>
        {subtitle && (
          <p className="mt-5 max-w-[580px] text-[17px] leading-relaxed text-[var(--color-muted)]">
            {subtitle}
          </p>
        )}
      </div>
    </header>
  );
}
