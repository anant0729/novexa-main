import Link from "next/link";
import Image from "next/image";
import { Mail, Phone, MapPin, Linkedin, Facebook, Instagram } from "lucide-react";

const NAV_LINKS: [string, string][] = [
  ["Home", "/"],
  ["Services", "/services"],
  ["Industries", "/industries"],
  ["About Us", "/about"],
  ["Contact", "/contact"],
];

const SERVICE_LINKS: [string, string][] = [
  ["POSM Solutions", "/services#posm-solutions"],
  ["Printing & Packaging", "/services#printing-packaging"],
  ["Retail Branding", "/services#retail-indoor-outdoor-branding"],
  ["Corporate Gifting", "/services#corporate-gifting"],
];

const SOCIALS: { label: string; href: string; icon: typeof Linkedin; hoverBg: string }[] = [
  { label: "LinkedIn", href: "#", icon: Linkedin, hoverBg: "hover:bg-[#0A66C2] hover:border-[#0A66C2]" },
  { label: "Facebook", href: "https://www.facebook.com/share/1DFHcaNn6L/", icon: Facebook, hoverBg: "hover:bg-[#1877F2] hover:border-[#1877F2]" },
  { label: "Instagram", href: "https://www.instagram.com/novexa.global2021?igsh=cmx4d2M2YjJudGcx", icon: Instagram, hoverBg: "hover:bg-gradient-to-tr hover:from-[#feda75] hover:via-[#d62976] hover:to-[#4f5bd5] hover:border-[#d62976]" },
];

export function Footer() {
  return (
    <footer className="bg-[#060c18] text-[#8a9ab5]">
      <div className="mx-auto max-w-[1200px] px-6 py-14 lg:px-8 lg:py-16">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-[1.3fr_1fr_1fr_1.2fr]">
          {/* brand */}
          <div>
            <div className="inline-flex rounded-xl bg-white px-3 py-2">
              <Image src="/novexa-logo.png" alt="Novexa Global" width={180} height={45} className="h-9 w-auto" />
            </div>
            <p className="mt-4 max-w-[280px] text-[13.5px] leading-relaxed text-[#8a9ab5]">
              Branding, printing, POSM manufacturing, corporate gifting and event activations,
              executed end to end across India.
            </p>
            <div className="mt-5 flex gap-3">
              {SOCIALS.map(({ label, href, icon: Icon, hoverBg }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className={`flex h-9 w-9 items-center justify-center rounded-full border border-[#1a2a42] text-[#8a9ab5] transition-all duration-200 hover:text-white ${hoverBg}`}
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {/* nav */}
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-[0.15em] text-white">Company</div>
            <ul className="mt-4 space-y-2.5">
              {NAV_LINKS.map(([label, href]) => (
                <li key={href}>
                  <Link href={href} className="text-[13.5px] transition-colors hover:text-white">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* services */}
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-[0.15em] text-white">Services</div>
            <ul className="mt-4 space-y-2.5">
              {SERVICE_LINKS.map(([label, href]) => (
                <li key={href}>
                  <Link href={href} className="text-[13.5px] transition-colors hover:text-white">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* contact */}
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-[0.15em] text-white">Get in Touch</div>
            <ul className="mt-4 space-y-3">
              <li>
                <a href="mailto:marketing@novexa-global.in" className="flex items-start gap-2.5 text-[13.5px] transition-colors hover:text-white">
                  <Mail className="mt-0.5 h-4 w-4 shrink-0 text-[#f97316]" strokeWidth={1.7} />
                  marketing@novexa-global.in
                </a>
              </li>
              <li>
                <a href="tel:+919818747929" className="flex items-start gap-2.5 text-[13.5px] transition-colors hover:text-white">
                  <Phone className="mt-0.5 h-4 w-4 shrink-0 text-[#f97316]" strokeWidth={1.7} />
                  +91 9818747929
                </a>
              </li>
              <li className="flex items-start gap-2.5 text-[13.5px]">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-[#f97316]" strokeWidth={1.7} />
                B-321, Plot No-4, Logix Technova, Sector-132, Noida 201304
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-[#1a2a42] pt-6 sm:flex-row">
          <div className="text-[11px] font-semibold uppercase tracking-[0.2em] text-[#4a7fa5]">
            Executing Ideas | Expanding Brands
          </div>
          <div className="text-[12.5px]">© {new Date().getFullYear()} Novexa Global Pvt Ltd. All rights reserved.</div>
        </div>
      </div>
    </footer>
  );
}
