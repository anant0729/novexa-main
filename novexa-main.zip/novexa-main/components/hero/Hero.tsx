"use client";

import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowRight } from "lucide-react";
import Link from "next/link";
import { useRef } from "react";
import { Magnetic } from "@/components/ui/Magnetic";

const fade = {
  hidden: {
    opacity: 0,
    y: 20,
  },
  show: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.7,
      delay: 0.15 + i * 0.1,
      ease: [0.22, 1, 0.36, 1] as const,
    },
  }),
};

const TRUST = [
  ["6+", "Years Executing"],
  ["100+", "Clients"],
  ["24+", "States Covered"],
];

export function Hero() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start start", "end start"],
  });

  const videoScale = useTransform(scrollYProgress, [0, 1], [1, 1.08]);
  const videoRadius = useTransform(scrollYProgress, [0, 1], [28, 0]);
  const textOpacity = useTransform(scrollYProgress, [0, 0.6], [1, 0]);
  const textY = useTransform(scrollYProgress, [0, 1], [0, -60]);

  return (
    <header ref={sectionRef} className="relative overflow-hidden bg-white">

      {/* Background */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,#fff7ed_0%,transparent_40%),radial-gradient(circle_at_bottom_left,#eff6ff_0%,transparent_40%)]" />

      <div className="relative z-10 mx-auto max-w-[1450px] px-5 pb-14 pt-[132px] sm:px-6 sm:pb-20 sm:pt-[148px] lg:px-10 lg:py-32 lg:pt-[168px]">

        <div className="grid items-center gap-10 lg:grid-cols-[1fr_1fr] lg:gap-16 xl:grid-cols-[0.95fr_1.05fr]">

          {/* LEFT */}
          <motion.div
            initial="hidden"
            animate="show"
            style={{ opacity: textOpacity, y: textY }}
            className="space-y-6 sm:space-y-8"
          >

            <motion.div variants={fade} custom={0}>

              <h1 className="max-w-xl text-[clamp(30px,7vw,44px)] font-black leading-[1.15] tracking-[-0.03em] text-[#0a0f1a]">

                We turn your brand into{" "}

                <span className="text-[#f97316]">
                  something people remember.
                </span>

              </h1>

              <p className="mt-4 max-w-xl text-base leading-7 text-[#5f6b80] sm:mt-6 sm:text-lg sm:leading-9">

                POSM Manufacturing, Printing & Packaging,
                Custom Display Units, Corporate Gifting,
                and Event & Campaign Activations -
                One execution partner from concept to installation,
                delivering across PAN India.

              </p>

            </motion.div>

            {/* CTA */}

            <motion.div
              variants={fade}
              custom={1}
              className="flex flex-wrap gap-3 sm:gap-4"
            >

              <Magnetic>
                <Link
                  href="/contact"
                  className="
                  group
                  inline-flex
                  items-center
                  rounded-full
                  bg-[#f97316]
                  px-6
                  py-3.5
                  text-sm
                  font-semibold
                  text-white
                  shadow-lg
                  transition-all
                  duration-300
                  hover:scale-[1.03]
                  hover:bg-[#ea580c]
                  sm:px-8
                  sm:py-4
                  "
                >
                  Get a Quote

                  <ArrowRight className="ml-2 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />

                </Link>
              </Magnetic>

              <Link
                href="/services"
                className="inline-flex items-center rounded-full border border-slate-200 bg-white px-6 py-3.5 text-sm font-semibold text-[#0a0f1a] transition-all duration-300 hover:border-[#f97316] hover:bg-orange-50 sm:px-8 sm:py-4"
              >
                Explore Services
              </Link>

            </motion.div>

            {/* TRUST */}

            <motion.div
              variants={fade}
              custom={2}
              className="grid max-w-md grid-cols-3 gap-2 sm:max-w-none sm:gap-4"
            >

              {TRUST.map(([number, label]) => (
                <div
                  key={label}
                  className="
                  rounded-xl
                  border
                  border-slate-200
                  bg-white/80
                  backdrop-blur
                  px-2.5
                  py-2.5
                  transition-all
                  duration-300
                  hover:-translate-y-1
                  hover:border-orange-200
                  hover:shadow-lg
                  sm:rounded-2xl
                  sm:px-5
                  sm:py-4
                  "
                >
                  <p className="text-base font-black text-[#0a0f1a] sm:text-2xl">
                    {number}
                  </p>

                  <p className="mt-0.5 text-[9px] uppercase leading-tight tracking-[0.1em] text-[#5f6b80] sm:mt-1 sm:text-[11px] sm:tracking-[0.18em]">
                    {label}
                  </p>
                </div>
              ))}

            </motion.div>

            {/* VIDEO - mobile/tablet, inline below CTA */}

            <motion.div
              variants={fade}
              custom={3}
              className="relative -mx-5 aspect-[4/3] w-[calc(100%+2.5rem)] overflow-hidden rounded-2xl bg-[#0a0f1a] shadow-[0_20px_50px_-16px_rgba(10,15,26,0.3)] sm:-mx-6 sm:aspect-video sm:w-[calc(100%+3rem)] sm:rounded-[28px] lg:hidden"
            >
              <video
                className="h-full w-full object-cover"
                src="/hero-video.mp4"
                poster="/about/office-1.jpg"
                autoPlay
                muted
                loop
                playsInline
              />
            </motion.div>

          </motion.div>

          {/* RIGHT - video, laptop/desktop only, scroll-linked */}

          <motion.div
            variants={fade}
            custom={3}
            initial="hidden"
            animate="show"
            className="relative hidden lg:block"
          >
            <motion.div
              style={{ scale: videoScale, borderRadius: videoRadius }}
              className="relative ml-auto w-full max-w-[600px] origin-center overflow-hidden bg-[#0a0f1a] shadow-[0_30px_80px_-20px_rgba(10,15,26,0.25)]"
            >
              <video
                className="h-auto w-full"
                src="/hero-video.mp4"
                poster="/about/office-1.jpg"
                autoPlay
                muted
                loop
                playsInline
              />
            </motion.div>
          </motion.div>

        </div>

      </div>

    </header>
  );
}