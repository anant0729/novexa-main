"use client";

import { useCallback, useMemo, useRef, useState, useEffect } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { useInView } from "framer-motion";
import * as THREE from "three";

/* ---------- data ---------- */
type Hub = { name: string; lat: number; lon: number; stat: string };
const HUBS: Hub[] = [
  { name: "Delhi NCR", lat: 28.6, lon: 77.2, stat: "HQ · production & client servicing" },
  { name: "Mumbai", lat: 19.1, lon: 72.9, stat: "Retail & media activations" },
  { name: "Bengaluru", lat: 12.97, lon: 77.6, stat: "Corporate gifting & events" },
  { name: "Ahmedabad", lat: 23.0, lon: 72.6, stat: "POSM manufacturing partners" },
  { name: "Kolkata", lat: 22.6, lon: 88.4, stat: "Eastern region rollout" },
];
const ARCS: [number, number][] = [[0, 1], [0, 2], [0, 3], [1, 4], [2, 3]];

/* ---------- helpers ---------- */
const R = 62;
function ll2v(lat: number, lon: number, r: number) {
  const phi = ((90 - lat) * Math.PI) / 180;
  const th = ((lon + 180) * Math.PI) / 180;
  return new THREE.Vector3(
    -r * Math.sin(phi) * Math.cos(th),
    r * Math.cos(phi),
    r * Math.sin(phi) * Math.sin(th)
  );
}
function radialTex(inner: string, outer: string) {
  const c = document.createElement("canvas");
  c.width = c.height = 64;
  const g = c.getContext("2d")!;
  const grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grd.addColorStop(0, inner);
  grd.addColorStop(0.4, inner);
  grd.addColorStop(1, outer);
  g.fillStyle = grd;
  g.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(c);
}

type MouseState = { nx: number; ny: number; px: number; py: number } | null;
function Scene({
  mouseRef,
  tooltipRef,
}: {
  mouseRef: React.RefObject<MouseState>;
  tooltipRef: React.RefObject<HTMLDivElement | null>;
}) {
  const globeRef = useRef<THREE.Group>(null);
  const reduced = useMemo(
    () => typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches,
    []
  );
  const lastName = useRef("");
  const tmp = useMemo(() => new THREE.Vector3(), []);
  const camDir = useMemo(() => new THREE.Vector3(), []);

  const built = useMemo(() => {
    const mobile = typeof window !== "undefined" && window.innerWidth < 768;
    const dotTex = radialTex("rgba(255,255,255,1)", "rgba(255,255,255,0)");

    // occluding core so back dots hide -> reads as a globe
    const core = new THREE.Mesh(
      new THREE.SphereGeometry(R * 0.985, 48, 48),
      new THREE.MeshBasicMaterial({ color: 0x060e1b })
    );

    // dotted surface (fibonacci sphere)
    const N = mobile ? 1500 : 3200;
    const pos = new Float32Array(N * 3);
    const gold = Math.PI * (3 - Math.sqrt(5));
    for (let i = 0; i < N; i++) {
      const y = 1 - (i / (N - 1)) * 2;
      const rr = Math.sqrt(1 - y * y);
      const th = gold * i;
      pos[i * 3] = Math.cos(th) * rr * R * 1.004;
      pos[i * 3 + 1] = y * R * 1.004;
      pos[i * 3 + 2] = Math.sin(th) * rr * R * 1.004;
    }
    const dg = new THREE.BufferGeometry();
    dg.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    const dots = new THREE.Points(
      dg,
      new THREE.PointsMaterial({
        color: 0xbcd6ff,
        size: 2.7,
        map: dotTex,
        transparent: true,
        opacity: 1,
        depthWrite: false,
        sizeAttenuation: true,
      })
    );

    // graticule (single LineSegments for perf)
    const seg: number[] = [];
    const pushRing = (pts: THREE.Vector3[]) => {
      for (let i = 0; i < pts.length - 1; i++) {
        seg.push(pts[i].x, pts[i].y, pts[i].z, pts[i + 1].x, pts[i + 1].y, pts[i + 1].z);
      }
    };
    for (let lon = -150; lon <= 180; lon += 30) {
      const p: THREE.Vector3[] = [];
      for (let lat = -90; lat <= 90; lat += 4) p.push(ll2v(lat, lon, R * 1.006));
      pushRing(p);
    }
    for (let lat = -60; lat <= 60; lat += 30) {
      const p: THREE.Vector3[] = [];
      for (let lon = -180; lon <= 180; lon += 4) p.push(ll2v(lat, lon, R * 1.006));
      pushRing(p);
    }
    const gg = new THREE.BufferGeometry();
    gg.setAttribute("position", new THREE.Float32BufferAttribute(seg, 3));
    const grat = new THREE.LineSegments(
      gg,
      new THREE.LineBasicMaterial({ color: 0x5183cc, transparent: true, opacity: 0.32 })
    );

    // atmosphere fresnel rim
    const atmo = new THREE.Mesh(
      new THREE.SphereGeometry(R * 1.18, 48, 48),
      new THREE.ShaderMaterial({
        transparent: true,
        blending: THREE.AdditiveBlending,
        side: THREE.BackSide,
        depthWrite: false,
        uniforms: { c: { value: new THREE.Color(0x3f7fff) } },
        vertexShader: `varying vec3 vN; varying vec3 vP;
          void main(){ vN=normalize(normalMatrix*normal);
            vec4 mv=modelViewMatrix*vec4(position,1.); vP=mv.xyz;
            gl_Position=projectionMatrix*mv; }`,
        fragmentShader: `varying vec3 vN; varying vec3 vP; uniform vec3 c;
          void main(){ float i=pow(1.0-abs(dot(vN,normalize(-vP))),2.6);
            gl_FragColor=vec4(c,i*0.34); }`,
      })
    );

    // hub nodes
    const nodeTex = radialTex("rgba(255,200,120,1)", "rgba(243,154,30,0)");
    const hubGroup = new THREE.Group();
    const nodes = HUBS.map((h) => {
      const p = ll2v(h.lat, h.lon, R * 1.01);
      const s = new THREE.Sprite(
        new THREE.SpriteMaterial({
          map: nodeTex,
          color: 0xffffff,
          transparent: true,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
        })
      );
      s.position.copy(p);
      s.scale.set(11, 11, 1);
      hubGroup.add(s);
      return { sprite: s, data: h };
    });

    // arcs + travelling pulses
    const pulseTex = radialTex("rgba(255,210,140,1)", "rgba(243,154,30,0)");
    const arcGroup = new THREE.Group();
    const pulses = ARCS.map((a, k) => {
      const v1 = ll2v(HUBS[a[0]].lat, HUBS[a[0]].lon, R * 1.01);
      const v2 = ll2v(HUBS[a[1]].lat, HUBS[a[1]].lon, R * 1.01);
      const mid = v1
        .clone()
        .add(v2)
        .multiplyScalar(0.5)
        .normalize()
        .multiplyScalar(R * (1.18 + (v1.distanceTo(v2) / R) * 0.16));
      const curve = new THREE.QuadraticBezierCurve3(v1, mid, v2);
      const tube = new THREE.Mesh(
        new THREE.TubeGeometry(curve, 48, 0.35, 6, false),
        new THREE.MeshBasicMaterial({ color: 0x234b85, transparent: true, opacity: 0.75 })
      );
      arcGroup.add(tube);
      const pulse = new THREE.Sprite(
        new THREE.SpriteMaterial({
          map: pulseTex,
          color: 0xffffff,
          transparent: true,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
        })
      );
      pulse.scale.set(7, 7, 1);
      arcGroup.add(pulse);
      return { curve, pulse, t: k * 0.2, sp: 0.08 + Math.random() * 0.05 };
    });

    // stars
    const SN = mobile ? 500 : 1100;
    const sp = new Float32Array(SN * 3);
    for (let i = 0; i < SN; i++) {
      const r = 600 + Math.random() * 500;
      const t = Math.random() * Math.PI * 2;
      const ph = Math.acos(2 * Math.random() - 1);
      sp[i * 3] = r * Math.sin(ph) * Math.cos(t);
      sp[i * 3 + 1] = r * Math.sin(ph) * Math.sin(t);
      sp[i * 3 + 2] = r * Math.cos(ph);
    }
    const sg = new THREE.BufferGeometry();
    sg.setAttribute("position", new THREE.BufferAttribute(sp, 3));
    const stars = new THREE.Points(
      sg,
      new THREE.PointsMaterial({
        color: 0x9fb6d6,
        size: 1.4,
        transparent: true,
        opacity: 0.6,
        map: dotTex,
        depthWrite: false,
      })
    );

    return { core, dots, grat, atmo, hubGroup, nodes, arcGroup, pulses, stars };
  }, []);

  useFrame((state, delta) => {
    const g = globeRef.current;
    if (g && !reduced) g.rotation.y += delta * 0.07;

    const t = state.clock.elapsedTime;
    built.nodes.forEach((n, i) => {
      const s = 10 + Math.sin(t * 3 + i) * 2.2;
      n.sprite.scale.set(s, s, 1);
    });
    if (!reduced) {
      built.pulses.forEach((p) => {
        p.t += delta * p.sp;
        if (p.t > 1) p.t -= 1;
        p.curve.getPoint(p.t, p.pulse.position);
      });
    }

    // camera parallax (eased)
    const m = mouseRef.current;
    const tx = m ? m.nx * 40 : 0;
    const ty = m ? 30 - m.ny * 30 : 30;
    state.camera.position.x += (tx - state.camera.position.x) * 0.05;
    state.camera.position.y += (ty - state.camera.position.y) * 0.05;
    state.camera.lookAt(0, 0, 0);

    // hover -> HTML tooltip (imperative, no re-render)
    const tip = tooltipRef.current;
    if (!tip) return;
    if (!m) {
      tip.style.opacity = "0";
      return;
    }
    const { width, height } = state.size;
    let best: { sx: number; sy: number; node: (typeof built.nodes)[number] } | null = null;
    let bd = 1e9;
    for (const n of built.nodes) {
      n.sprite.getWorldPosition(tmp);
      const world = tmp.clone();
      tmp.project(state.camera);
      const sx = (tmp.x * 0.5 + 0.5) * width;
      const sy = (-tmp.y * 0.5 + 0.5) * height;
      camDir.copy(state.camera.position).sub(world).normalize();
      if (world.clone().normalize().dot(camDir) < 0.12) continue; // back-facing
      const d = Math.hypot(sx - m.px, sy - m.py);
      if (d < 26 && d < bd) {
        bd = d;
        best = { sx, sy, node: n };
      }
    }
    if (best) {
      tip.style.left = `${best.sx}px`;
      tip.style.top = `${best.sy}px`;
      tip.style.opacity = "1";
      if (lastName.current !== best.node.data.name) {
        lastName.current = best.node.data.name;
        (tip.querySelector("[data-name]") as HTMLElement).textContent = best.node.data.name;
        (tip.querySelector("[data-stat]") as HTMLElement).textContent = best.node.data.stat;
      }
    } else {
      tip.style.opacity = "0";
    }
  });

  return (
    <>
      <primitive object={built.stars} />
      <group rotation={[-0.12, 0, 0.32]}>
        <primitive object={built.atmo} />
        <group ref={globeRef}>
          <primitive object={built.core} />
          <primitive object={built.dots} />
          <primitive object={built.grat} />
          <primitive object={built.hubGroup} />
          <primitive object={built.arcGroup} />
        </group>
      </group>
    </>
  );
}

export default function Globe() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);
  const mouseRef = useRef<MouseState>(null);
  const inView = useInView(wrapRef);
  const mobile = typeof window !== "undefined" && window.innerWidth < 768;
  const [webglSupported, setWebglSupported] = useState<boolean | null>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const c = document.createElement("canvas");
      const ctx = (c.getContext("webgl2") || c.getContext("webgl")) as WebGLRenderingContext | null;
      setWebglSupported(!!ctx);
    } catch (e) {
      setWebglSupported(false);
    }
  }, []);

  const onMove = useCallback((e: React.PointerEvent<HTMLDivElement>) => {
    const el = wrapRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    mouseRef.current = {
      nx: (e.clientX - r.left) / r.width - 0.5,
      ny: (e.clientY - r.top) / r.height - 0.5,
      px: e.clientX - r.left,
      py: e.clientY - r.top,
    };
  }, []);

  return (
    <div
      ref={wrapRef}
      className="relative h-full w-full"
      onPointerMove={onMove}
      onPointerLeave={() => (mouseRef.current = null)}
    >
      <Canvas
        className="h-full w-full"
        style={{ position: "absolute", inset: 0 }}
        frameloop={inView ? "always" : "never"}
        dpr={[1, mobile ? 1.5 : 2]}
        camera={{ position: [0, 20, 420], fov: 34 , near: 1, far: 2000 }}
        gl={{ antialias: !mobile, alpha: true, powerPreference: "high-performance" }}
      >
        <Scene mouseRef={mouseRef} tooltipRef={tooltipRef} />
      </Canvas>

      <div
        ref={tooltipRef}
        style={{ opacity: 0 }}
        className="glass pointer-events-none absolute z-10 min-w-[140px] -translate-x-1/2 -translate-y-[128%] rounded-xl px-3 py-2.5 shadow-2xl transition-opacity duration-150"
      >
        <div className="flex items-center gap-2 font-[family-name:var(--font-display)] text-sm font-semibold text-white">
          <span className="h-[7px] w-[7px] rounded-full bg-[var(--color-orange)] shadow-[0_0_10px_var(--color-orange)]" />
          <span data-name>India</span>
        </div>
        <div data-stat className="mt-1 font-[family-name:var(--font-mono)] text-[11px] text-[#9fb6d6]" />
      </div>

      {webglSupported === false && (
        <div className="absolute inset-0 flex items-center justify-center bg-[var(--color-navy)] text-sm text-[#8a9ab5]">
          3D preview unavailable in this browser
        </div>
      )}
    </div>
  );
}