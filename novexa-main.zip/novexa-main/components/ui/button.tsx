import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

/**
 * Lightweight shadcn-style Button, restyled with Novexa brand variants.
 * For links styled as buttons, apply `buttonVariants(...)` to a <Link>/<a>
 * (e.g. <Link className={buttonVariants({ variant: "primary" })} />).
 * Run `npx shadcn@latest add button` later if you want the full Radix version.
 */
export const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-xl font-[family-name:var(--font-display)] font-semibold transition-[transform,box-shadow,background,border-color] duration-200 ease-[cubic-bezier(0.22,1,0.36,1)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-blue-int)] disabled:opacity-50 will-change-transform active:scale-[0.98] cursor-pointer",
  {
    variants: {
      variant: {
        primary:
          "bg-[var(--color-orange)] text-[#1a1205] shadow-[0_2px_10px_rgba(243,154,30,0.32)] hover:shadow-[0_8px_26px_rgba(243,154,30,0.40)]",
        ghost:
          "bg-transparent text-white border border-white/20 hover:border-white/45 hover:bg-white/5",
        ghostDark:
          "bg-transparent text-[var(--color-ink)] border border-[var(--color-line)] hover:border-[var(--color-blue-int)] hover:bg-white",
      },
      size: {
        md: "h-[46px] px-[22px] text-[15px]",
        sm: "h-[38px] px-4 text-sm",
      },
    },
    defaultVariants: { variant: "primary", size: "md" },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, ...props }, ref) => (
    <button ref={ref} className={cn(buttonVariants({ variant, size, className }))} {...props} />
  )
);
Button.displayName = "Button";
