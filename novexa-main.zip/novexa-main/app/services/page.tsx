import type { Metadata } from "next";
import { Navbar } from "@/components/layout/Navbar";
import { PageHero } from "@/components/layout/PageHero";
import { ServicesBody } from "@/components/sections/ServicesBody";
import { ContactCTA } from "@/components/sections/ContactCTA";
import { Footer } from "@/components/layout/Footer";
import { FloatingWhatsApp } from "@/components/layout/FloatingWhatsApp";

export const metadata: Metadata = {
  title: "Services",
  description:
    "POSM solutions, printing & packaging, retail branding, custom display units, influencer marketing, event activations, brand partnerships, social strategy, online reputation management and corporate gifting - one accountable partner across the whole build.",
};

export default function ServicesPage() {
  return (
    <>
      <Navbar />
      <PageHero
        kicker=""
        title="One accountable partner, across the whole build."
        subtitle="From concept to install, our services exist to remove the handoffs - engage one, or hand us the entire brand execution."
      />
      <ServicesBody />
      <ContactCTA />
      <Footer />
      <FloatingWhatsApp />
    </>
  );
}
