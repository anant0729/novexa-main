import Link from "next/link";
import { buttonVariants } from "@/components/ui/button";
import { Footer } from "@/components/layout/Footer";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col bg-white">
      <main className="flex flex-1 flex-col items-center justify-center px-7 text-center">
        <p className="font-[family-name:var(--font-mono)] text-[11.5px] uppercase tracking-[0.18em] text-[var(--color-orange-deep)]">
          404 - Page not found
        </p>
        <h1 className="heading mt-5 text-[clamp(36px,6vw,76px)] text-[var(--color-blue-deep)]">
          This page doesn&apos;t exist.
        </h1>
        <p className="mt-5 max-w-[420px] text-[16.5px] leading-relaxed text-[var(--color-muted)]">
          The page you&apos;re looking for doesn&apos;t exist or was moved. Let&apos;s get you back
          to a known route.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link href="/" className={buttonVariants({ variant: "primary" })}>
            Back to Home
          </Link>
          <Link href="/contact" className={buttonVariants({ variant: "ghostDark" })}>
            Get a Quote
          </Link>
        </div>
      </main>
      <Footer />
    </div>
  );
}
