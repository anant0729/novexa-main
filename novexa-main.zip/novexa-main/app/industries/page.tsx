import type { Metadata } from "next";
import { Navbar } from "@/components/layout/Navbar";
import { PageHero } from "@/components/layout/PageHero";
import { IndustryTabs } from "@/components/sections/IndustryTabs";
import { ContactCTA } from "@/components/sections/ContactCTA";
import { Footer } from "@/components/layout/Footer";
import { FloatingWhatsApp } from "@/components/layout/FloatingWhatsApp";

export const metadata: Metadata = {
  title: "Industries",
  description:
    "Sector-specific branding, POSM and activation experience across media, BFSI, consumer durables, fintech, agriculture and retail - each with its own rollout playbook.",
};

export default function IndustriesPage() {
  return (
    <>
      <Navbar />
      <PageHero
        kicker=""
        title="Sector expertise, not generic branding."
        subtitle="Every industry has its own rollout speed, compliance needs and finish standards. Pick yours to see how we execute for it specifically."
      />
      <IndustryTabs />
      <ContactCTA />
      <Footer />
      <FloatingWhatsApp />
    </>
  );
}
