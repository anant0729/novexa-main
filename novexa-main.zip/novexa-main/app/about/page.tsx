import type { Metadata } from "next";
import { Navbar } from "@/components/layout/Navbar";
import { PageHero } from "@/components/layout/PageHero";
import { AboutBody } from "@/components/sections/AboutBody";
import { ContactCTA } from "@/components/sections/ContactCTA";
import { Footer } from "@/components/layout/Footer";
import { FloatingWhatsApp } from "@/components/layout/FloatingWhatsApp";

export const metadata: Metadata = {
  title: "About",
  description:
    "Novexa Global is a leading provider of Branding, Printing, Retail Branding, POSM manufacturing, Corporate Gifting and Event & Campaign Activation solutions across India.",
};

export default function AboutPage() {
  return (
    <>
      <Navbar />
      <PageHero
        kicker=""
        title="Executing ideas. Expanding brands."
        subtitle="Six years helping businesses enhance their brand visibility through innovative, high-quality and cost-effective marketing solutions across India."
      />
      <AboutBody />
      <ContactCTA />
      <Footer />
      <FloatingWhatsApp />
    </>
  );
}
