import type { Metadata } from "next";
import { Geist, Geist_Mono, Inter } from "next/font/google";
import { SmoothScroll } from "@/components/layout/SmoothScroll";
import "./globals.css";

const geist = Geist({ subsets: ["latin"], variable: "--font-geist", display: "swap" });
const geistMono = Geist_Mono({ subsets: ["latin"], variable: "--font-geist-mono", display: "swap" });
const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });

const SITE = "https://novexa-global.in";

export const metadata: Metadata = {
  metadataBase: new URL(SITE),
  title: {
    default: "Novexa Global - Branding, Printing & POSM Solutions",
    template: "%s · Novexa Global",
  },
  description:
    "Novexa Global is a PAN-India branding, printing and POSM partner - retail branding, display manufacturing, corporate gifting and event activations, executed end to end for brands like Kohler, Adani and NDTV.",
  keywords: [
    "branding agency India",
    "POSM manufacturer India",
    "retail branding company",
    "printing solutions India",
    "corporate gifting company",
    "event activation agency",
  ],
  openGraph: {
    type: "website",
    url: SITE,
    siteName: "Novexa Global",
    title: "Novexa Global - Branding, Printing & POSM Solutions",
    description:
      "Retail branding, printing, POSM manufacturing, corporate gifting and event activations - executed end to end, across PAN India.",
  },
  twitter: { card: "summary_large_image", title: "Novexa Global", description: "Executing ideas. Expanding brands." },
  robots: { index: true, follow: true },
  alternates: { canonical: SITE },
};

const orgJsonLd = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "Novexa Global Pvt Ltd",
  url: SITE,
  description: "Branding, printing, POSM manufacturing, corporate gifting and event activation solutions across India.",
  areaServed: "India",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${geist.variable} ${geistMono.variable} ${inter.variable}`}>
      <body>
        <SmoothScroll />
        {children}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(orgJsonLd) }}
        />
      </body>
    </html>
  );
}
