import type { MetadataRoute } from "next";

const BASE = "https://novexa-global.in";

export default function sitemap(): MetadataRoute.Sitemap {
  const routes = [
    { path: "", priority: 1.0, freq: "weekly" },
    { path: "/about", priority: 0.9, freq: "monthly" },
    { path: "/services", priority: 0.9, freq: "monthly" },
    { path: "/industries", priority: 0.85, freq: "monthly" },
    { path: "/contact", priority: 0.95, freq: "weekly" },
  ] as const;

  return routes.map(({ path, priority, freq }) => ({
    url: `${BASE}${path}`,
    lastModified: new Date(),
    changeFrequency: freq as MetadataRoute.Sitemap[number]["changeFrequency"],
    priority,
  }));
}
