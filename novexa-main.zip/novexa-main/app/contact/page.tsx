import type { Metadata } from "next";
import { Navbar } from "@/components/layout/Navbar";
import { PageHero } from "@/components/layout/PageHero";
import { ContactBody } from "@/components/sections/ContactBody";
import { Footer } from "@/components/layout/Footer";
import { FloatingWhatsApp } from "@/components/layout/FloatingWhatsApp";

export const metadata: Metadata = {
  title: "Contact",
  description:
    "Tell us what you need to build. Get a tailored plan - scope, timeline and indicative pricing - within one business day.",
};

export default function ContactPage() {
  return (
    <>
      <Navbar />
      <PageHero
        kicker="Get In Touch"
        title="Tell us what you need to build."
        subtitle="Share your requirement and our team will get back within one business day. Prefer to talk now? Message us on WhatsApp."
      />
      <ContactBody />
      <Footer />
      <FloatingWhatsApp />
    </>
  );
}
