# Novexa Global — Website

Marketing site for Novexa Global (branding, printing, POSM manufacturing, corporate
gifting and event activations). Next.js App Router + Tailwind CSS v4 + Framer Motion,
with Lenis for smooth scrolling.

## Setup

```bash
npm install
npm run dev          # http://localhost:3000
npm run build && npm start
```

## Pages

| Route | File |
|---|---|
| `/` | `app/page.tsx` |
| `/about` | `app/about/page.tsx` |
| `/services` | `app/services/page.tsx` |
| `/industries` | `app/industries/page.tsx` |
| `/contact` | `app/contact/page.tsx` |

## Structure

```
components/
  hero/       Hero.tsx (homepage hero, video panel)
  layout/     Navbar.tsx · PageHero.tsx · Footer.tsx · FloatingWhatsApp.tsx · SmoothScroll.tsx
  sections/   homepage sections (About, Services, OurWork, Clients, WhyChooseUs, ContactCTA)
              + subpage bodies (AboutBody, ServicesBody, IndustryTabs, ContactBody)
  ui/         button.tsx · Magnetic.tsx
```

## Notes

- `ServicesBody.tsx` exports the `SERVICES` list — shared by the Services page, homepage
  Services carousel, and the navbar's Services dropdown. Update it in one place.
- Contact form (`ContactBody.tsx`) has its `submit()` handler ready for a backend — wire up
  the commented `fetch()` call and set `NEXT_PUBLIC_API_URL` when a backend exists.
- Hero video expects a file at `public/hero-video.mp4`.
